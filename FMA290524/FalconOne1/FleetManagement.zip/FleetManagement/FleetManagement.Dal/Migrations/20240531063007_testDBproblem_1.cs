﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FleetManagement.Dal.Migrations
{
    /// <inheritdoc />
    public partial class testDBproblem_1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Adressen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Straat = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Nummer = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Stad = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Postcode = table.Column<string>(type: "varchar(10)", maxLength: 10, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    IsVerwijderd = table.Column<bool>(type: "tinyint(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Adressen", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Autos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Merk = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Model = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Type = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ChassisNummer = table.Column<string>(type: "varchar(17)", maxLength: 17, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Nummerplaat = table.Column<string>(type: "varchar(9)", maxLength: 9, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    BrandstofType = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Kleur = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AantalDeuren = table.Column<string>(type: "varchar(2)", maxLength: 2, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    IsBeschikbaar = table.Column<bool>(type: "tinyint(1)", nullable: false),
                    IsVerwijderd = table.Column<bool>(type: "tinyint(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Autos", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Brandstoffen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Naam = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    IsVerwijderd = table.Column<bool>(type: "tinyint(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Brandstoffen", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Tankkaarten",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Kaartnummer = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    GeldigheidsDatum = table.Column<DateTime>(type: "datetime(6)", maxLength: 50, nullable: false),
                    Pincode = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Brandstof = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    IsBeschikbaar = table.Column<bool>(type: "tinyint(1)", nullable: false),
                    IsGeblokkeerd = table.Column<bool>(type: "tinyint(1)", nullable: false),
                    IsVerwijderd = table.Column<bool>(type: "tinyint(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tankkaarten", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Bestuurders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Naam = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Voornaam = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Geboortedatum = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    RijksregisterNummer = table.Column<string>(type: "varchar(14)", maxLength: 14, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    TypeRijbewijs = table.Column<string>(type: "varchar(3)", maxLength: 3, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AutoId = table.Column<int>(type: "int", nullable: true),
                    TankkaartId = table.Column<int>(type: "int", nullable: true),
                    AdresId = table.Column<int>(type: "int", nullable: true),
                    IsVerwijderd = table.Column<bool>(type: "tinyint(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bestuurders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Bestuurders_Adressen_AdresId",
                        column: x => x.AdresId,
                        principalTable: "Adressen",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Bestuurders_Autos_AutoId",
                        column: x => x.AutoId,
                        principalTable: "Autos",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Bestuurders_Tankkaarten_TankkaartId",
                        column: x => x.TankkaartId,
                        principalTable: "Tankkaarten",
                        principalColumn: "Id");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Historiek",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Datum = table.Column<DateTime>(type: "datetime(6)", maxLength: 50, nullable: false),
                    AutoId = table.Column<int>(type: "int", nullable: true),
                    BestuurderId = table.Column<int>(type: "int", nullable: true),
                    TankkaartId = table.Column<int>(type: "int", nullable: true),
                    IsVerwijderd = table.Column<bool>(type: "tinyint(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Historiek", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Historiek_Autos_AutoId",
                        column: x => x.AutoId,
                        principalTable: "Autos",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Historiek_Bestuurders_BestuurderId",
                        column: x => x.BestuurderId,
                        principalTable: "Bestuurders",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Historiek_Tankkaarten_TankkaartId",
                        column: x => x.TankkaartId,
                        principalTable: "Tankkaarten",
                        principalColumn: "Id");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateIndex(
                name: "IX_Autos_ChassisNummer",
                table: "Autos",
                column: "ChassisNummer",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Autos_Nummerplaat",
                table: "Autos",
                column: "Nummerplaat",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Bestuurders_AdresId",
                table: "Bestuurders",
                column: "AdresId");

            migrationBuilder.CreateIndex(
                name: "IX_Bestuurders_AutoId",
                table: "Bestuurders",
                column: "AutoId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Bestuurders_RijksregisterNummer",
                table: "Bestuurders",
                column: "RijksregisterNummer",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Bestuurders_TankkaartId",
                table: "Bestuurders",
                column: "TankkaartId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Historiek_AutoId",
                table: "Historiek",
                column: "AutoId");

            migrationBuilder.CreateIndex(
                name: "IX_Historiek_BestuurderId",
                table: "Historiek",
                column: "BestuurderId");

            migrationBuilder.CreateIndex(
                name: "IX_Historiek_TankkaartId",
                table: "Historiek",
                column: "TankkaartId");

            migrationBuilder.CreateIndex(
                name: "IX_Tankkaarten_Kaartnummer",
                table: "Tankkaarten",
                column: "Kaartnummer",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Brandstoffen");

            migrationBuilder.DropTable(
                name: "Historiek");

            migrationBuilder.DropTable(
                name: "Bestuurders");

            migrationBuilder.DropTable(
                name: "Adressen");

            migrationBuilder.DropTable(
                name: "Autos");

            migrationBuilder.DropTable(
                name: "Tankkaarten");
        }
    }
}
