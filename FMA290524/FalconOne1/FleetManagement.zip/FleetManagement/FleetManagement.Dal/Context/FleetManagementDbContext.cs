﻿using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Extensions;
using Microsoft.EntityFrameworkCore;

namespace FleetManagement.Dal.Context
{
    public class FleetManagementDbContext : DbContext
    {

        //_dbcontext = vertegenwoordigt een sessie met de databank. (entiteiten beheren en configureren)
        //_dbSet is een verzameling van alle entiteiten -> zie FleetmanagerDbContext -> zoals een tabel in de DB


        //Constructor
        public FleetManagementDbContext() : base()
        {
        }

        //Constructor Options
        public FleetManagementDbContext(DbContextOptions options) : base(options)
        {
        }

        //DB sets met meervoud kolomnamen.
        public DbSet<Adres> Adressen { get; set; }
        public DbSet<Auto> Autos { get; set; } 
        public DbSet<Bestuurder> Bestuurders { get; set; }
        public DbSet<Brandstof> Brandstoffen { get; set; }
        public DbSet<Tankkaart> Tankkaarten { get; set; }
        public DbSet<Historiek> Historiek{ get; set; }


        //Connectionstring via JSON file
        //Eventueel kan de connectionstring in de OnConfiguring methode ook worden meegegeven als back up -> niet 100% save.
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //Dit wordt nu via appsettings en program.cs afgehandeld, steeds mogelijk deze terug te activeren als backup

            //if (!optionsBuilder.IsConfigured)
            //{
            //    optionsBuilder.UseSqlServer("Data Source=.\\SQLEXPRESS;Initial Catalog=fleetManagementDb;Integrated Security = True; Trusted_Connection = True; TrustServerCertificate = True;");
            //}
        }


        //OnModelCreating bij aanmaken en aanpassen DB, dus wordt niet elke keer uitgevoerd.
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        //Configuratie databank
        //Zie Extensions

            modelBuilder.AutoConfig();
            modelBuilder.TankkaartConfig();
            modelBuilder.BrandstofConfig();
            modelBuilder.BestuurderConfig();
            modelBuilder.AdresConfig();
            modelBuilder.HistoriekConfig();
        }
    }
}
