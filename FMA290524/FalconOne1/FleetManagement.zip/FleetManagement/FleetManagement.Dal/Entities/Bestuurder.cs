﻿
namespace FleetManagement.Dal.Entities
{

  /*Id wordt voorzien door de BaseEntity klasse. 
   *Toewijzen van auto en tankkaart verloopt via de FK ID's
   *Indien een bestuurder niet meer ter beschikking is (vb ontslag), wordt IsVerwijderd op true geplaatst => softdelete met oog op historische gegevens.
   */
   
    public class Bestuurder : BaseEntity
    {
        public string Naam { get; set; }
        public string Voornaam { get; set; }
        public string Geboortedatum { get; set; }
        public string RijksregisterNummer { get; set; }
        public string TypeRijbewijs { get; set; }   
       

        //Kunnen NULL zijn, wanneer er bijvoorbeeld slechts 1 van de 3 is toegewezen.
        public int? AutoId { get; set; }
        public Auto Auto { get; set; }  

        public int? TankkaartId { get; set; }
        public Tankkaart Tankkaart { get; set; }

        public int? AdresId { get; set; }
        public Adres Adres { get; set; }

    }
}
