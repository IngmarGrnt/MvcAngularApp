﻿
namespace FleetManagement.Dal.Entities
{

   /*Id wordt voorzien door de BaseEntity klasse. 
    *Indien een auto niet meer (dus nooit) ter beschikking is, wordt IsVerwijderd op true geplaatst => softdelete met oog op historische gegevens.
    *Wanneer een auto reeds toegewezen is aan een bestuurder en/of tijdelijk defect is, wordt IsBeschikbaar op false geplaatst => met oog op filteren. */

    public class Auto : BaseEntity
    {
        public string Merk { get; set; } 
        public string Model { get; set; }   
        public string Type { get; set; }
        public string ChassisNummer {  get; set; }
        public string Nummerplaat { get; set; }
        public string BrandstofType {  get; set; }
        public string Kleur {  get; set; }
        public string AantalDeuren { get; set; }
        public bool IsBeschikbaar { get; set; }
       
    }
}
