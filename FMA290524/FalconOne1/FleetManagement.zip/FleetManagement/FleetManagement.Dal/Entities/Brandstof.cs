﻿namespace FleetManagement.Dal.Entities
{
    /*Aparte tabel voor brandstof, zo de ADMIN extra brandstoffen kan toevoegen. Deze zullen worden weergegeven door een listval in de UI
     *Id wordt voorzien door de BaseEntity klasse*/
    public class Brandstof : BaseEntity
   {
        public string Naam { get; set; }
   }
}
