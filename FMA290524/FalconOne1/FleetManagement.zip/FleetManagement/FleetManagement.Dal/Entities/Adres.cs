﻿namespace FleetManagement.Dal.Entities
{
    /*Id wordt voorzien door de BaseEntity klasse.
     Adres voor de bestuurder, in aparte klasse*/

    //Indien het nodig is om alle bestuurders (indien meerdere op 1 adres) van een adres te kunnen opvragen is er nog een list nodig,relevantie ?
    public class Adres:BaseEntity
    {
        public string Straat { get; set; }
        public string Nummer { get; set; }
        public string Stad {  get; set; }   
        public string Postcode { get; set; }    
   
    }
}
