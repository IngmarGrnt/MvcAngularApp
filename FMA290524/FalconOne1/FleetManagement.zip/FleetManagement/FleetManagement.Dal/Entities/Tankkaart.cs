﻿

namespace FleetManagement.Dal.Entities
{
    /*Id wordt voorzien door de BaseEntity klasse. 
    *Brandstof wordt bij aanmaken van een TankkaartObject meegegeven als string door de GUI. (vb -> listval met keuze) => lijst wordt dynamisch gevuld door DB.
    *Indien een tankkaart niet meer (dus nooit) ter beschikking is, wordt IsVerwijderd op true geplaatst => softdelete met oog op historische gegevens.
    *Wanneer een tankkaart reeds toegewezen is aan een bestuurder, wordt IsBeschikbaar op false geplaatst => met oog op filteren.
    *Indien een tankkaart geblokkeerd wordt, wordt IsGeblokkeerd true.
    *Degelijke bools zorgen voor een mogelijkheid tot specifiek filteren */
    public class Tankkaart :BaseEntity
    {
       public string Kaartnummer {  get; set; }
       public DateTime GeldigheidsDatum { get; set; }
       public string Pincode { get; set; }
       public string Brandstof { get; set; }
       public bool IsBeschikbaar { get; set; }
       public bool IsGeblokkeerd { get; set; }
    }
}
