﻿namespace FleetManagement.Dal.Entities
{
    /* Id wordt voorzien door de BaseEntity klasse.
     Aparte tabel om alle transacties te loggen en zo een historiek bij te houden.*/
    public class Historiek : BaseEntity
    {
        public DateTime Datum { get; set; }

        //Foreign keys
        //Kan NULL bevatten, indien een persoon een auto heeft, maar bijvoorbeeld nog nooit een tankkaart heeft gehad. (Te reviewen tijdens code)
        public int? AutoId { get; set; }
        public int? BestuurderId { get; set; }
        public int? TankkaartId { get; set; }
    }
}
