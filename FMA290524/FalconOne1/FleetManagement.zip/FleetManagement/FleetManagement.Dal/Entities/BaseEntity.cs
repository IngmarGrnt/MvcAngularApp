﻿

namespace FleetManagement.Dal.Entities
{
    /*BaseEntity zal veranwtoordelijk zijn voor een globale ID bij alle Entities*/
    public class BaseEntity
    {
        public int Id { get; set; }
        public bool IsVerwijderd { get; set; }
        
    }
}
