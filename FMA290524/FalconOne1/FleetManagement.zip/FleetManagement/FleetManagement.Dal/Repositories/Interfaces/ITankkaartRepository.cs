﻿namespace FleetManagement.Dal.Repositories.Interfaces
{
    public interface ITankkaartRepository
    {
        Task<bool> CheckDuplicateKaartnummer(string kaartNummer, int currentEntityId);
    }
}
