﻿namespace FleetManagement.Dal.Repositories.Interfaces
{
    public interface IAutoRepository
    {
        Task<bool> CheckDuplicateNummerplaatAsync(string nummerplaat, int id);
        Task<bool> CheckDuplicateChassisNummerAsync(string nummerplaat, int id);
    }
}
