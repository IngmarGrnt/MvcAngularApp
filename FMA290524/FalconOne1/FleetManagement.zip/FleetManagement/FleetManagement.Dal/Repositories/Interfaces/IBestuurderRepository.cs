﻿using FleetManagement.Dal.Entities;

namespace FleetManagement.Dal.Repositories.Interfaces
{
    public  interface IBestuurderRepository : IGenericRepository<Bestuurder>
    {
        int? ZoekAdresId(string straat, string nummer, string postcode, string stad);
        Task<bool> CheckDuplicateRijksregisterNr(string rijksregisterNr, int currentEntityId);
        void SetAutotIdNull(int bestuurderId);
        void SetTankkaartIdNull(int tankkaartId);
        bool AutoIsLinkedToABestuurder(int id);
    }
}
