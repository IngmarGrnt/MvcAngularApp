﻿namespace FleetManagement.Dal.Repositories.Interfaces
{
    public interface IGenericRepository<Entity>
    {

        List<Entity> GetAll();
        Task<List<Entity>> GetAllAsync();
        void SoftDelete(int id);
        Entity GetById(int id);
        int Add(Entity entity);
        void Update(Entity entity);
        void Delete(int id);
        void SaveChanges();
    }
}
