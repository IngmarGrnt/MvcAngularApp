﻿using FleetManagement.Dal.Context;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FleetManagement.Dal.Repositories
{
    public class AutoRepository : GenericRepository<Auto>, IAutoRepository
    {
        public AutoRepository(FleetManagementDbContext context) : base(context) { }

        public async Task<bool> CheckDuplicateNummerplaatAsync(string nummerplaat, int currentEntityId)
        {
            try
            {
                var existingAuto = await _dbcontext.Autos
                .FirstOrDefaultAsync(a => a.Nummerplaat == nummerplaat && a.Id != currentEntityId);
                return existingAuto != null;
                //checkt of er in de db al een nummerplaaat inzit die niet dezelfde id heeft als de huidige geselecteerde auto
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }  
        }

        public async Task<bool> CheckDuplicateChassisNummerAsync(string chassisnummer, int currentEntityId)
        {
            try
            {
                var existingAuto = await _dbcontext.Autos
                .FirstOrDefaultAsync(a => a.ChassisNummer == chassisnummer && a.Id != currentEntityId);
                return existingAuto != null;
                //checkt of er in de db al een chasssisnummer inzit die niet dezelfde id heeft als de huidige geselecteerde auto
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
