﻿using FleetManagement.Dal.Context;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;


namespace FleetManagement.Dal.Repositories
{
    //BestuurderRepository neemt alle (crud) functionaliteit van GenericRepository over, maar voegt enkele toe specifiek voor Bestuurder.
    //Uiteraard met zijn eigen interface
    public class BestuurderRepository : GenericRepository<Bestuurder>, IBestuurderRepository
    {
        public BestuurderRepository(FleetManagementDbContext context) : base(context)
        {
        }

        public int? ZoekAdresId(string straat, string nummer, string postcode, string stad)
        {
            //Zoek naar een adres dat overeenkomt met alle opgegeven criteria.

            try
            {
               var adres = _dbcontext.Adressen
              .Where(a => a.Straat == straat &&
                          a.Nummer == nummer &&
                          a.Postcode == postcode &&
                          a.Stad == stad)
              .FirstOrDefault(); //Gebruik FirstOrDefault om null te krijgen als er geen match is.

                return adres?.Id; //Gebruik de null-conditional operator om null terug te geven als adres null is.
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
        public async Task<bool> CheckDuplicateRijksregisterNr(string rijksregisterNr, int currentEntityId)
        {
            try
            {
                var existingRijksRegisterNr = await _dbcontext.Bestuurders
               .FirstOrDefaultAsync(a => a.RijksregisterNummer == rijksregisterNr && a.Id != currentEntityId);
                return existingRijksRegisterNr != null;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void SetTankkaartIdNull(int tankkaartId)
        {

            try { 

                 var bestuurder = _dbcontext.Bestuurders
                .Where(b=>b.TankkaartId==tankkaartId).FirstOrDefault();   

                if (bestuurder != null)
                {
                    bestuurder.TankkaartId = null;
                    SaveChanges();
                }
                
            }
            catch (Exception ex)
            {
                throw new Exception("Fout bij het bijwerken van de Bestuurder TankaartId, alvorens op te slaan in de DB. " + ex.Message, ex);
            }
        }

        public void SetAutotIdNull(int bestuurderId)
        {
            try
            {
                var bestuurder = _dbcontext.Bestuurders
                     .Where(b => b.AutoId == bestuurderId).FirstOrDefault();

            if (bestuurder == null)
            {
                throw new ArgumentNullException(nameof(bestuurder), "Bestuurder niet gevonden, update niet mogelijk.");
            }

                bestuurder.AutoId = null;
            }
            catch (Exception ex)
            {
                throw new Exception("Fout bij het bijwerken van de Bestuurder, alvorens op te slaan in de DB. " + ex.Message, ex);
            }

            SaveChanges();
        }

        public bool AutoIsLinkedToABestuurder(int autoId)
        {
            try
            {
                return _dbcontext.Bestuurders.Any(b => b.AutoId == autoId);
                //returns true vanaf er 1 bestuurder is die de auto id heeft, anders false
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }
}
