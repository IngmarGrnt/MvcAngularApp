﻿using FleetManagement.Dal.Context;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Data.Common;


namespace FleetManagement.Dal.Repositories
{
    //Meer controle krijgen door de BaseEntity mee te geven ipv de algemene CLASS.
    public class GenericRepository<Entity> :IGenericRepository<Entity>
        where Entity : BaseEntity
    {

        //Generic zorgt voor basis crud
        //internal voor toegang overerving klassen
        //Virtual laat toe om later in de andere repo's de CRUD methodes specifiek aan te passen op maat -> override.
        //_dbSet is een verzameling van alle entiteiten -> zie FleetmanagerDbContext -> zoals een tabel in de DB
        //_dbcontext =  vertegenwoordigt een sessie met de databank. (entiteiten beheren en configureren)
        //Zowel Dbcontext als dbset kunnen aangeroepen worden.


        internal readonly FleetManagementDbContext _dbcontext;
        internal readonly DbSet<Entity> _dbSet;


        public GenericRepository(FleetManagementDbContext context)
        {
            _dbcontext = context;
            _dbSet = _dbcontext.Set<Entity>();
        }

        public virtual List<Entity> GetAll()
        {
            try
            {
                return _dbSet.ToList();
            }
            catch (ArgumentNullException)
            {
                throw new ArgumentNullException($"Ophalen lijst is mislukt. ");
            }
            catch (DbUpdateException ex)
            {
                throw new Exception("Entityframework DB fout bij het ophalen van alle gegevens uit DB. " +  ex.Message, ex); //+inner exception
            }
            catch (DbException ex)
            {
                throw new Exception("Databank fout bij het ophalen van alle gegevens uit DB. " +  ex.Message, ex);
            }
            catch (Exception ex)
            {

                throw new Exception("Algemene fout bij het ophalen van alle gegevens uit DB. " +  ex.Message, ex);
            }

        }

        public async Task<List<Entity>> GetAllAsync()
        {
            try
            {
                return await _dbSet.ToListAsync();
            }
            catch (ArgumentNullException)
            {
                throw new ArgumentNullException($"Ophalen lijst is mislukt.");
            }
            catch (DbUpdateException ex)
            {
                throw new Exception("Entityframework DB fout, bij ophalen alle gegevens uit DB. " +  ex.Message, ex); //+inner exception
            }
            catch (DbException ex)
            {
                throw new Exception("Databank fout bij het ophalen van alle gegevens uit DB. " +  ex.Message, ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Algemene fout bij het ophalen van alle gegevens uit DB. " +  ex.Message, ex);
            }
        }

        public virtual Entity GetById(int id)
        {
            try
            {
                var entity = _dbSet.FirstOrDefault(db => db.Id == id);   //Id lukt omdat de BaseEntity dit heeft.
                if (entity == null)
                {
                    throw new ArgumentNullException($"Een entiteit met ID {id} is niet gevonden");
                }

                return entity;
            }
            catch (DbUpdateException ex)
            {
                throw new Exception("Entityframework DB fout bij het ophalen van gegevens uit DB via ID. " +  ex.Message, ex); //+inner exception
            }
            catch (DbException ex)
            {
                throw new Exception("Databank fout bij het ophalen van gegevens uit DB via ID. " +  ex.Message, ex);
            }

            catch (Exception ex)
            {
                throw new Exception("Algemene fout bij het ophalen van gegevens uit DB via ID. "+  ex.Message, ex);
            }
            
        }

        public virtual int Add(Entity entity)
        {

            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity), "Entiteit niet beschikbaar, toevoegen niet mogelijk.");
            }

            try
            {
                _dbSet.Add(entity);
            }
           
            catch (Exception ex)
            {
                throw new Exception("Fout bij het toevoegen van de entiteit, alvorens op te slaan in de DB " +  ex.Message, ex);
            }

            SaveChanges();
            return entity.Id;
        }


        public virtual void Update(Entity entity)
        {

            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity), " Entiteit niet beschikbaar, update niet mogelijk.");
            }

            try
            {
                _dbSet.Update(entity);
            }

            catch (Exception ex)
            {
                throw new Exception("Fout bij het bijwerken van de entiteit, alvorens op te slaan in de DB. " +  ex.Message, ex);
            }

            SaveChanges();
        }

        public virtual void Delete(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentNullException($"Een entiteit met ID {id} is niet gevonden");
            }

            try
            {
                //Hierdoor is apart saven bij delete niet meer nodig.
                var entity = _dbSet.Where(x => x.Id == id).ExecuteDelete();
            }
            catch (DbUpdateException ex)
            {
                throw new Exception("Entityframework DB fout, bij het verwijderen. " +  ex.Message, ex); //+inner exception
            }
            catch (DbException ex)
            {

                throw new Exception("Databank fout bij het verwijderen van gegevens. " +  ex.Message, ex);
            }
            catch (Exception ex)
            {

                throw new Exception("Algemene fout bij het verwijderen van gegevens. " +  ex.Message, ex);
            }
           
        }

        public virtual void SoftDelete(int id)
        {
            try
            {
                var entity = _dbSet.FirstOrDefault(x => x.Id == id);
                if (entity == null)
                {
                    throw new ArgumentNullException($"Een entiteit met ID {id} is niet gevonden");
                }
                else
                {
                    entity.IsVerwijderd = true;
                }
            }
        
            catch (Exception ex)
            {
                throw new Exception("Algemene fout bij softdelete. " +  ex.Message, ex);
            }
           
            SaveChanges();
        }

        //fouten voor savechanges wijzen op fouten met de data of de applicatie. (Nog geen connectie gemaakt met de db.)
        //interactie met database
        public void SaveChanges()
        {
            try
            {
                _dbcontext.SaveChanges();
            }
            catch (DbUpdateException ex)
            { 
                throw new Exception("Entity Framework DB-fout, bij het opslaan van gegevens naar de databank. " + ex.Message, ex);
                
            }
            catch (DbException ex)
            {
                throw new Exception("Databank fout bij het opslaan van gegevens naar de databank. " + ex.Message, ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Algemene fout bij het opslaan van gegevens naar de databank. " + ex.Message, ex);
            }

        }
    }
}
