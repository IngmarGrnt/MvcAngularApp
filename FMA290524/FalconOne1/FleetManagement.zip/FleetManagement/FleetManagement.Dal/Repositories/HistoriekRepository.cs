﻿using FleetManagement.Dal.Context;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;

namespace FleetManagement.Dal.Repositories
{
    //HistoriekRepository neemt alle functionaliteit van GenericRepository over, maar specifiek voor Historiek.
    //Uiteraard met zijn eigen interface
    public class HistoriekRepository : GenericRepository<Historiek>, IHistoriekRepository
    {
        public HistoriekRepository(FleetManagementDbContext context) : base(context)
        {
        }
    }
}
