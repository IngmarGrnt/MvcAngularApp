﻿using FleetManagement.Dal.Context;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FleetManagement.Dal.Repositories
{
    public class TankkaartRepository : GenericRepository<Tankkaart>, ITankkaartRepository
    {
        public TankkaartRepository(FleetManagementDbContext context) : base(context)
        {
        }

        public async Task<bool> CheckDuplicateKaartnummer(string kaartNummer, int currentEntityId)
        {
            try
            {
                var existingKaartNummer = await _dbcontext.Tankkaarten
                .FirstOrDefaultAsync(a => a.Kaartnummer == kaartNummer && a.Id != currentEntityId);

                return existingKaartNummer != null;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
    }
}
