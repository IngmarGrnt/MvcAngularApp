﻿using FleetManagement.Dal.Entities;
using Microsoft.EntityFrameworkCore;

namespace FleetManagement.Dal.Extensions
{
    //Config items van de entiteiten voor EF => zie OnModelCreatingMethode in fleetmanagementDbcontext.
    public static class ExtensionMethods
    {

        public static void AutoConfig(this ModelBuilder mb)
        {

            //verplichte attributen

            mb.Entity<Auto>()
              .HasKey(a => a.Id);

            mb.Entity<Auto>()
              .Property(a => a.Merk)
              .IsRequired(true)
              .HasMaxLength(25);

            mb.Entity<Auto>()
              .Property(a => a.Model)
              .IsRequired(true)
              .HasMaxLength(25);

            mb.Entity<Auto>()
              .Property(a => a.Type)
              .IsRequired(true)
              .HasMaxLength(25);

            mb.Entity<Auto>()
              .Property(a => a.ChassisNummer)
              .IsRequired(true)
              .HasMaxLength(17); //Chassisnummer heeft altijd 17 tekens.

            //Uniek afdwingen van ChassisNummer
            mb.Entity<Auto>()
              .HasIndex(a => a.ChassisNummer)    //Index is nodig om IsUnique te kunnen gebruiken.
              .IsUnique();

            mb.Entity<Auto>()
              .Property(a => a.Nummerplaat)
              .IsRequired(true)
              .HasMaxLength(9); //nummerplaat heeft 7 tekens en 2 koppeltekens.

            //Uniek afdwingen van Nummerplaat
            mb.Entity<Auto>()
              .HasIndex(a => a.Nummerplaat)    //Index is nodig om IsUnique te kunnen gebruiken.
              .IsUnique();

            mb.Entity<Auto>()
              .Property(a => a.BrandstofType)
              .IsRequired(true)
              .HasMaxLength(25);

            //Niet verplichte attributen 

            mb.Entity<Auto>()
              .Property(a => a.Kleur)
              .IsRequired(false)
              .HasMaxLength(25);

            mb.Entity<Auto>()
              .Property(a => a.AantalDeuren)
              .IsRequired(false)
              .HasMaxLength(2); //normaal max 1, toch 1 reserve.

            //Bools niet nodig om specifiek toe te wijzen aangezien deze geen NULL kunnen hebben.
        }

        public static void TankkaartConfig(this ModelBuilder mb)
        {

            //verplichte attributen 

            mb.Entity<Tankkaart>()
             .HasKey(t => t.Id);

            mb.Entity<Tankkaart>()
              .Property(t => t.Kaartnummer)
              .IsRequired(true)
              .HasMaxLength(20);

            //Uniek afdwingen van kaartnummer
            mb.Entity<Tankkaart>()
              .HasIndex(t => t.Kaartnummer)    //Index is nodig om IsUnique te kunnen gebruiken.
              .IsUnique();

            mb.Entity<Tankkaart>()
              .Property(t => t.GeldigheidsDatum)
              .IsRequired(true)
              .HasMaxLength(50);

            //niet verplichte attributen

            mb.Entity<Tankkaart>()
             .Property(t => t.Pincode)
             .IsRequired(false)
             .HasMaxLength(4);

            mb.Entity<Tankkaart>()
              .Property(t => t.Brandstof)
              .IsRequired(false)
              .HasMaxLength(20);

            //Bools niet nodig om specifiek toe te wijzen aangezien deze geen NULL kunnen hebben.
        }

        public static void BrandstofConfig(this ModelBuilder mb)
        {
            mb.Entity<Brandstof>()
             .HasKey(b => b.Id);

            mb.Entity<Brandstof>()
              .Property(b => b.Naam)
              .IsRequired(true)
              .HasMaxLength(20);
        }

        public static void BestuurderConfig(this ModelBuilder mb)
        {

            //verplichte attributen 

            mb.Entity<Bestuurder>()
             .HasKey(b => b.Id);

            mb.Entity<Bestuurder>()
             .Property(b => b.Naam)
             .IsRequired(true)
             .HasMaxLength(25);

            mb.Entity<Bestuurder>()
            .Property(b => b.Voornaam)
            .IsRequired(true)
            .HasMaxLength(25);

            mb.Entity<Bestuurder>()
            .Property(b => b.Geboortedatum)
            .IsRequired(true)
            .HasMaxLength(20);

            mb.Entity<Bestuurder>()
            .Property(b => b.TypeRijbewijs)
            .IsRequired(true)
            .HasMaxLength(3); //1 extra, normaal slechts 2 nodig: A,B,CE,ect..

            mb.Entity<Bestuurder>()
            .Property(b => b.RijksregisterNummer)
            .IsRequired(true)
            .HasMaxLength(14); //11 cijfers + 3 tekens 

            mb.Entity<Bestuurder>()
            .HasIndex(b => b.RijksregisterNummer)    //Index is nodig om IsUnique te kunnen gebruiken.
            .IsUnique();


            //Bools niet nodig om specifiek toe te wijzen aangezien deze geen NULL kunnen hebben.

            //relaties 
            mb.Entity<Bestuurder>()
              .Property(b => b.AutoId)
              .IsRequired(false);

            mb.Entity<Bestuurder>()
              .Property(b => b.TankkaartId)
              .IsRequired(false);

            mb.Entity<Bestuurder>()
              .Property(b => b.AdresId)
              .IsRequired(false);

            mb.Entity<Bestuurder>()
            .HasOne(b => b.Auto) //Bestuurder heeft 1 auto.                           
            .WithOne() //Auto hoeft geen weet te hebben wie zijn bestuurder is.
            .HasForeignKey<Bestuurder>(b => b.AutoId); //bestuurder heeft weet van de FK van AUTO.

            mb.Entity<Bestuurder>()
            .HasOne(b => b.Tankkaart)
            .WithOne()
            .HasForeignKey<Bestuurder>(b => b.TankkaartId);

            mb.Entity<Bestuurder>()
            .HasOne(b => b.Adres)
            .WithMany() //adress kan meerdere bestuurders hebben (koppel) toch moet adres niet weten wie zijn bestuurders zijn.
            .HasForeignKey(b => b.AdresId);
        }

        public static void AdresConfig(this ModelBuilder mb)
        {
            mb.Entity<Adres>()
            .HasKey(a => a.Id);

            mb.Entity<Adres>()
             .Property(a => a.Straat)
             .IsRequired(true)
             .HasMaxLength(50);

            mb.Entity<Adres>()
           .Property(a => a.Nummer)
           .IsRequired(true)
           .HasMaxLength(4);

            mb.Entity<Adres>()
           .Property(a => a.Stad)
           .IsRequired(true)
           .HasMaxLength(20);

            mb.Entity<Adres>()
           .Property(a => a.Postcode)
           .IsRequired(true)
           .HasMaxLength(10); //extra voor eventueel buitenland
        }

        public static void HistoriekConfig(this ModelBuilder mb)
        {
            mb.Entity<Historiek>()
            .HasKey(h => h.Id);

            mb.Entity<Historiek>()
             .Property(h => h.Datum)
             .IsRequired(true)
             .HasMaxLength(50);

            //relaties 
            //mag null zijn, bijvoorbeeld wanneer er enkel een auto is toegekent, maar nog geen tankkaart.
            mb.Entity<Historiek>()
               .HasOne<Auto>()
               .WithMany()
               .HasForeignKey(h => h.AutoId)
               .IsRequired(false);


            mb.Entity<Historiek>()
              .HasOne<Tankkaart>()
              .WithMany()
              .HasForeignKey(h => h.TankkaartId)
              .IsRequired(false);

            mb.Entity<Historiek>()
            .HasOne<Bestuurder>()
            .WithMany()
            .HasForeignKey(h => h.BestuurderId)
            .IsRequired(false);
        }
    }
}
