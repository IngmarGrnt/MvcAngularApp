﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers;
using FleetManagement.Dal.Repositories.Interfaces;
using FleetManagement.Dal.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TestingMSTest
{
    [TestClass]
    public class BestuurderManagerTests
    {
        private BestuurderManager _bestuurderManager;
        private Mock<IBestuurderRepository> _bestuurderRepositoryMock;
        private Mock<IGenericRepository<Adres>> _adresRepositoryMock;
        private Mock<IGenericRepository<Historiek>> _historiekRepositoryMock;
        private Mock<IMapper> _mapperMock;

        [TestInitialize]
        public void Setup()
        {
            _bestuurderRepositoryMock = new Mock<IBestuurderRepository>();
            _adresRepositoryMock = new Mock<IGenericRepository<Adres>>();
            _historiekRepositoryMock = new Mock<IGenericRepository<Historiek>>();
            _mapperMock = new Mock<IMapper>();

            _bestuurderManager = new BestuurderManager(
                _bestuurderRepositoryMock.Object,
                _adresRepositoryMock.Object,
                _historiekRepositoryMock.Object,
                _mapperMock.Object
            );
        }

        [TestMethod]
        public async Task GetAllBestuurdersAsync_Returns_List_Of_BestuurderDto()
        {
            // Arrange
            var bestuurders = new List<Bestuurder> { new Bestuurder(), new Bestuurder() };
            _bestuurderRepositoryMock.Setup(r => r.GetAll()).Returns(bestuurders);

            var bestuurderDtos = new List<BestuurderDto> { new BestuurderDto(), new BestuurderDto() };
            _mapperMock.Setup(m => m.Map<List<BestuurderDto>>(bestuurders)).Returns(bestuurderDtos);

            // Act
            var result = await _bestuurderManager.GetAllBestuurdersAsync();

            // Assert
            CollectionAssert.AreEqual(bestuurderDtos, result, "Moet een lijst van BestuurderDto's teruggeven");
        }

        [TestMethod]
        public void ValideerInputRijksregisterNummer_Invalid_Characters_Throws_ArgumentException()
        {
            // Arrange
            var bestuurderDto = new BestuurderDto { RijksregisterNummer = "01A203-405.06", Geboortedatum = new DateTime(2001, 2, 3) };

            // Act & Assert
            Assert.ThrowsException<ArgumentException>(() => _bestuurderManager.ValideerInputRijksregisterNummer(bestuurderDto), "Moet een ArgumentException gooien voor ongeldige tekens in het rijksregisternummer");
        }

        [TestMethod]
        public void ValideerInputRijksregisterNummer_Invalid_Length_Throws_ArgumentException()
        {
            // Arrange
            var bestuurderDto = new BestuurderDto { RijksregisterNummer = "010203-405.067", Geboortedatum = new DateTime(2001, 2, 3) };

            // Act & Assert
            Assert.ThrowsException<ArgumentException>(() => _bestuurderManager.ValideerInputRijksregisterNummer(bestuurderDto), "Moet een ArgumentException gooien voor een ongeldige lengte van het rijksregisternummer");
        }

        [TestMethod]
        public void ValideerInputRijksregisterNummer_Invalid_Date_Throws_ArgumentException()
        {
            // Arrange
            var bestuurderDto = new BestuurderDto { RijksregisterNummer = "010203-405.06", Geboortedatum = new DateTime(2000, 1, 1) };

            // Act & Assert
            Assert.ThrowsException<ArgumentException>(() => _bestuurderManager.ValideerInputRijksregisterNummer(bestuurderDto), "Moet een ArgumentException gooien als de geboortedatum niet overeenkomt met het rijksregisternummer");
        }

        [TestMethod]
        public void ValideerInputRijksregisterNummer_Invalid_ControlNumber_Throws_ArgumentException()
        {
            // Arrange
            var bestuurderDto = new BestuurderDto { RijksregisterNummer = "010203-405.07", Geboortedatum = new DateTime(2001, 2, 3) };

            // Act & Assert
            Assert.ThrowsException<ArgumentException>(() => _bestuurderManager.ValideerInputRijksregisterNummer(bestuurderDto), "Moet een ArgumentException gooien als het controlegetal van het rijksregisternummer ongeldig is");
        }
    }
}
