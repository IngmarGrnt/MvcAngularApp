using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TestingMSTest
{
    [TestClass]
    public class AutoManagerTests
    {
        private AutoManager _autoManager;
        private Mock<IAutoRepository> _autoRepositoryMock;
        private Mock<IGenericRepository<Auto>> _genericRepositoryMock;
        private Mock<IMapper> _mapperMock;
        private Mock<IBestuurderRepository> _bestuurderRepositoryMock;

        [TestInitialize]
        //wordt voor elke test gerund voor de setup voor de dependencies te setten
        public void Setup()
        {
            //mocked repo/mapper om te gebruiken in onze tests
            _autoRepositoryMock = new Mock<IAutoRepository>();
            _genericRepositoryMock = new Mock<IGenericRepository<Auto>>();
            _mapperMock = new Mock<IMapper>();
            _bestuurderRepositoryMock = new Mock<IBestuurderRepository>();

            _autoManager = new AutoManager(_autoRepositoryMock.Object, _genericRepositoryMock.Object, _mapperMock.Object, _bestuurderRepositoryMock.Object);
                //new AutoManager(_autoRepositoryMock.Object, _genericRepositoryMock.Object, _mapperMock.Object);
        }

        [TestMethod]
        public void AddAuto_returns_geldig_Id()
        {
            // Arrange
            var autoDto = new AutoDto(); // Dto object maken

            // Mock van dependencies
            _mapperMock.Setup(m => m.Map<Auto>(autoDto)).Returns(new Auto()); //mcoking zorgt voor mapping tussen autoDto en auto
            _genericRepositoryMock.Setup(g => g.Add(It.IsAny<Auto>())).Returns(1); 
            //^^ mockt de repo voor wanneer er een auto wordt geadd en returnt 1

            // Act
            int result = _autoManager.AddAuto(autoDto);

            // Assert
            Assert.AreEqual(1, result); // resultaat checken
        }

        [TestMethod]
        public async Task GetAllAutosAsync_Returns_Lijst_Van_AutoDto()
        {
            // Arrange
            //mocken vana auto's
            var autos = new List<Auto>(); 
            _genericRepositoryMock.Setup(g => g.GetAllAsync()).ReturnsAsync(autos);

            //mockt de mapper als er een lijst van autos wordt meegegeven dat deze een lijst van autodtos terug geeft
            var autoDtos = new List<AutoDto>();
            _mapperMock.Setup(m => m.Map<List<AutoDto>>(autos)).Returns(autoDtos);

            // Act
            var result = await _autoManager.GetAllAsync();

            // Assert
            CollectionAssert.AreEqual(autoDtos, result);
        }

        [TestMethod]
        public async Task CheckDuplicateNummerplaat_Returns_True_Voor_Duplicaat()
        {
            // Arrange
            const string nummerplaat = "ABC123";
            const int id = 1;

            _autoRepositoryMock.Setup(a => a.CheckDuplicateNummerplaatAsync(nummerplaat, id)).ReturnsAsync(true);

            // Act
            var result = await _autoManager.CheckDuplicateNummerplaat(nummerplaat, id);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task CheckDuplicateChassisNummer_Returns_True_Voor_Duplicaat()
        {
            // Arrange
            const string chassisnummer = "123456";
            const int id = 1;

            _autoRepositoryMock.Setup(a => a.CheckDuplicateChassisNummerAsync(chassisnummer, id)).ReturnsAsync(true);

            // Act
            var result = await _autoManager.CheckDuplicateChassisNummer(chassisnummer, id);

            // Assert
            Assert.IsTrue(result);
        }


        // NEGATIEVE CASES
        [TestMethod]
        public void AddAuto_Gooit_Exception_Als_AutoDto_Null_Is()
        {
            // Arrange
            AutoDto autoDto = null;

            // Act & Assert
            Assert.ThrowsException<ArgumentNullException>(() => _autoManager.AddAuto(autoDto));
        }

        [TestMethod]
        public async Task GetAllAutosAsync_Gooit_Exception_Als_GetAllAsync_Faalt()
        {
            // Arrange
            _genericRepositoryMock.Setup(g => g.GetAllAsync()).ThrowsAsync(new Exception("exception"));

            // Act & Assert
            await Assert.ThrowsExceptionAsync<Exception>(() => _autoManager.GetAllAsync());
        }

        [TestMethod]
        public async Task CheckDuplicateNummerplaat_Returns_False_Voor_Geen_Duplicaat()
        {
            // Arrange
            const string nummerplaat = "ABC123";
            const int id = 1;

            _autoRepositoryMock.Setup(a => a.CheckDuplicateNummerplaatAsync(nummerplaat, id)).ReturnsAsync(false);

            // Act
            var result = await _autoManager.CheckDuplicateNummerplaat(nummerplaat, id);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public async Task CheckDuplicateChassisNummer_Returns_False_Voor_Geen_Duplicaat()
        {
            // Arrange
            const string chassisnummer = "123456";
            const int id = 1;

            _autoRepositoryMock.Setup(a => a.CheckDuplicateChassisNummerAsync(chassisnummer, id)).ReturnsAsync(false);

            // Act
            var result = await _autoManager.CheckDuplicateChassisNummer(chassisnummer, id);

            // Assert
            Assert.IsFalse(result);
        }
    }
}
