﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestingMSTest
{
    [TestClass]
    public class BrandstofManagerTests
    {
        private BrandstofManager _brandstofManager;
        private Mock<IGenericRepository<Brandstof>> _repositoryMock;
        private Mock<IMapper> _mapperMock;

        [TestInitialize]
        public void Setup()
        {
            // Opzetten van mocks voor dependencies
            _repositoryMock = new Mock<IGenericRepository<Brandstof>>();
            _mapperMock = new Mock<IMapper>();

            // Init van brandstofmanager met mock obj
            _brandstofManager = new BrandstofManager(_repositoryMock.Object, _mapperMock.Object);
        }

        [TestMethod]
        public void AddBrandstof_returns_geldig_Id_voor_valid_AutoDTO()
        {
            // Arrange
            var brandstofDto = new BrandstofDto();

            // Mocken van de AutoMapper om het mapping proces te simuleren
            _mapperMock.Setup(m => m.Map<Brandstof>(brandstofDto)).Returns(new Brandstof());
            // Mocken van de repository om het toevoegen van een entiteit te simuleren
            _repositoryMock.Setup(r => r.Add(It.IsAny<Brandstof>())).Returns(1);

            // Act
            var result = _brandstofManager.AddBrandstof(brandstofDto);

            // Assert
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void DeleteBrandstof_InManager_Roept_1x_delete_op_in_repo()
        {
            // Arrange
            const int id = 1;

            // Act
            _brandstofManager.DeleteBrandstof(id);

            // Assert
            // Controleren of de Delete methode van de repository is aangeroepen
            _repositoryMock.Verify(r => r.Delete(id), Times.Once);
        }

        [TestMethod]
        public async Task GetAllBrandstofAsync_ReturnsLegeLijst_WhenRepositoryReturnsNull()
        {
            // Arrange
            // Mocken van de repository om null terug te geven
            _repositoryMock.Setup(r => r.GetAllAsync()).ReturnsAsync((List<Brandstof>)null);

            // Act
            var result = await _brandstofManager.GetAllBrandstofAsync();

            // Assert
            // Controleren of een lege lijst wordt geretourneerd als de repository null teruggeeft
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public async Task GetAllBrandstofAsync_GooitException_WhenRepositoryThrowsException()
        {
            // Arrange
            // Mocken van de repository om een uitzondering te gooien
            _repositoryMock.Setup(r => r.GetAllAsync()).ThrowsAsync(new Exception("Repository exception"));

            // Act & Assert
            // Controleren of een excepttion wordt opgegooid als de repository een excepttion gooit
            await Assert.ThrowsExceptionAsync<Exception>(() => _brandstofManager.GetAllBrandstofAsync());
        }
    }
}
