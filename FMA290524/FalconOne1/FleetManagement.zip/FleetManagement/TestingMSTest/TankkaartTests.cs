﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestingMSTest
{
    [TestClass]
    public class TankkaartManagerTests
    {
        private TankkaartManager _tankkaartManager;
        private Mock<IGenericRepository<Tankkaart>> _genericRepositoryMock;
        private Mock<IMapper> _mapperMock;
        private Mock<ITankkaartRepository> _tankkaartRepositoryMock;
        private Mock<IBestuurderRepository> _bestuurderRepositoryMock;

        [TestInitialize]
        public void Setup()
        {
            //setup, init van mocks, deze worden later in de tests gebruikt.
            _genericRepositoryMock = new Mock<IGenericRepository<Tankkaart>>();
            _mapperMock = new Mock<IMapper>();
            _tankkaartRepositoryMock = new Mock<ITankkaartRepository>();
            _bestuurderRepositoryMock = new Mock<IBestuurderRepository>();

            //init tankkaartmanager met mocks die net zijn aangemaakt
            _tankkaartManager = new TankkaartManager(_mapperMock.Object, _tankkaartRepositoryMock.Object, _genericRepositoryMock.Object, _bestuurderRepositoryMock.Object);
        }

        [TestMethod]
        public async Task GetAllTankkaartenAsync_Returns_TankkaartDto_Lijst()
        {
            // Arrange
            // mocken van de entiteiten en DTO's
            var tankkaarten = new List<Tankkaart> { new Tankkaart(), new Tankkaart() };
            var tankkaartDtoList = tankkaarten.Select(t => new TankkaartDto()).ToList();

            //mocken repo en mapper
            _genericRepositoryMock.Setup(r => r.GetAll()).Returns(tankkaarten);
            _mapperMock.Setup(m => m.Map<List<TankkaartDto>>(tankkaarten)).Returns(tankkaartDtoList);

            // Act
            var result = await _tankkaartManager.GetAllTankkaartenAsync();

            // Assert
            CollectionAssert.AreEqual(tankkaartDtoList, result);
        }

        [TestMethod]
        public async Task AddTankkaartAsync_Returns_Id()
        {
            // Arrange
            var tankkaartDto = new TankkaartDto();
            var tankkaart = new Tankkaart();
            const int expectedId = 1;

            _mapperMock.Setup(m => m.Map<Tankkaart>(tankkaartDto)).Returns(tankkaart);
            _genericRepositoryMock.Setup(r => r.Add(tankkaart)).Returns(expectedId);

            // Act
            var result = await _tankkaartManager.AddTankkaartAsync(tankkaartDto);

            // Assert
            Assert.AreEqual(expectedId, result);
        }

        [TestMethod]
        public async Task UpdateTankkaartAsync_Updates_Tankkaart()
        {
            // Arrange
            var tankkaartDto = new TankkaartDto { Id = 1 };
            var bestaandeTankkaart = new Tankkaart();
            _mapperMock.Setup(m => m.Map(tankkaartDto, bestaandeTankkaart)).Verifiable();
            _genericRepositoryMock.Setup(r => r.GetById(tankkaartDto.Id)).Returns(bestaandeTankkaart);

            // Act
            await _tankkaartManager.UpdateTankkaartAsync(tankkaartDto);

            // Assert
            _mapperMock.Verify(m => m.Map(tankkaartDto, bestaandeTankkaart), Times.Once);
            _genericRepositoryMock.Verify(r => r.Update(bestaandeTankkaart), Times.Once);
        }

        [TestMethod]
        public async Task CheckDuplicateKaartnummer_Returns_True_When_Duplicate_Found()
        {
            // Arrange
            //voorbereiden gegevens voor duplicaat controle
            const string kaartnummer = "123456";
            const int id = 1;

            _tankkaartRepositoryMock.Setup(r => r.CheckDuplicateKaartnummer(kaartnummer, id)).ReturnsAsync(true);

            // Act
            var result = await _tankkaartManager.CheckDuplicateKaartnummer(kaartnummer, id);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task SetTankkaartIdNullBestuurder_Calls_SetTankkaartIdNull()
        {
            // Arrange
            const int tankkaartId = 1;

            // Act
            _tankkaartManager.SetTankkaartIdNullBestuurder(tankkaartId);

            // Assert
            _bestuurderRepositoryMock.Verify(r => r.SetTankkaartIdNull(tankkaartId), Times.Once);
        }
    }
}
