﻿

using System.ComponentModel.DataAnnotations;

namespace FleetManagement.BL.Dto
{
    /* Kleur, deuren,.. worden bij aanmaken van een autoObject meegegeven als string door de GUI. (vb -> listval met keuze).
     * Indien een auto niet meer(dus nooit) ter beschikking is, wordt IsVerwijderd op true geplaatst => softdelete met oog op historische gegevens.
     * Wanneer een auto reeds toegewezen is aan een bestuurder en/of tijdelijk defect is, wordt IsBeschikbaar op false geplaatst => met oog op filteren. */

    public class AutoDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Merk is verplicht.")]
        public string Merk { get; set; }

        [Required(ErrorMessage = "Model is verplicht.")]
        public string Model { get; set; }

        [Required(ErrorMessage = "Type is verplicht.")]
        public string Type { get; set; }

        [Required(ErrorMessage = "Chassisnummer is verplicht.")]
        [StringLength(17, MinimumLength = 17, ErrorMessage = "Chassisnummer moet 17 karakters lang zijn.")]
        public string ChassisNUmmer { get; set; }

        [Required(ErrorMessage = "Nummerplaat is verplicht.")]
        [StringLength(9, MinimumLength = 9, ErrorMessage = "Nummerplaat moet 9 karakters lang zijn.")]
        public string Nummerplaat { get; set; }

        [Required(ErrorMessage = "Brandstof type is verplicht.")]
        public string BrandstofType { get; set; }

        public string Kleur { get; set; }
        
        [StringLength(1, ErrorMessage = "Aantal Deuren moet een geldig getal zijn van 1 karakter")]
        public string AantalDeuren { get; set; }

        public bool IsBeschikbaar { get; set; }

        public bool IsVerwijderd { get; set; }

        public DateTime Datum { get; set; }
    }
}
