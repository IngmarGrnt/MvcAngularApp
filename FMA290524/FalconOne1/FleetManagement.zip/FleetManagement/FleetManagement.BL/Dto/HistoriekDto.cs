﻿namespace FleetManagement.BL.Dto
{
    /* Aparte tabel om alle transacties te loggen en zo een historiek bij te houden.*/
    public class HistoriekDto
    {
        public int Id { get; set; }
        public DateTime Datum { get; set; }

        //Foreign keys, voor historiek is een ID voldoende. Geen nood aan volledige objecten. (Tabel kan mogelijks veel records bedragen, dus deze zo licht mogelijk houden)

        //Kan NULL bevatten, indien een persoon een auto heeft, maar bijvoorbeeld nog nooit een tankkaart heeft gehad. (Te reviewen tijdens code)
        public int? AutoId { get; set; }
        public int? BestuurderId { get; set; }
        public int? TankkaartId { get; set; }
    }
}
