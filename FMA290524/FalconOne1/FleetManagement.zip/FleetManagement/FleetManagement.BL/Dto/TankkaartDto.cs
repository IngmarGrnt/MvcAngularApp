﻿
using System.ComponentModel.DataAnnotations;

namespace FleetManagement.BL.Dto
{
    /*Brandstof wordt bij aanmaken van een TankkaartObject meegegeven als string door de GUI. (vb -> listval met keuze) => lijst wordt dynamisch gevuld door DB.
     *Indien een tankkaart niet meer (dus nooit) ter beschikking is, wordt IsVerwijderd op true geplaatst => softdelete met oog op historische gegevens.
     *Wanneer een tankkaart reeds toegewezen is aan een bestuurder, wordt IsBeschikbaar op false geplaatst => met oog op filteren.
     *Indien een tankkaart geblokkeerd wordt, wordt IsGeblokkeerd true.
     *Degelijke bools zorgen voor een mogelijkheid tot specifiek filteren */

    public class TankkaartDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Kaartnummer is verplicht.")]
        public string Kaartnummer { get; set; }

        [Required(ErrorMessage = "Geldigheidsdatum is verplicht.")]
        public DateTime GeldigheidsDatum { get; set; }

        [Required(ErrorMessage = "Pincode is verplicht.")]
        public string Pincode { get; set; }

        [Required(ErrorMessage = "Brandstof is verplicht.")]
        public string Brandstof { get; set; }

        public bool IsBeschikbaar { get; set; }
        public bool IsVerwijderd { get; set; }
        public bool IsGeblokkeerd { get; set; }
        public DateTime Datum {  get; set; }    
    }
}
