﻿namespace FleetManagement.BL.Dto
{
    /*Aparte tabel voor brandstof, zo de ADMIN extra brandstoffen kan toevoegen. Deze zullen worden weergegeven door een listval in de UI */
    public class BrandstofDto
    {
        public int Id { get; set; }

        public string? Naam { get; set; }
    }
}
