﻿using System.ComponentModel.DataAnnotations;
namespace FleetManagement.BL.Dto
{

    /*Toewijzen van auto en tankkaart verloopt via de FK ID's
    *Indien een bestuurder niet meer ter beschikking is (vb ontslag), wordt IsVerwijderd op true geplaatst => softdelete met oog op historische gegevens.
    */

    public class BestuurderDto 
    {
        //################ BESTUURDER ################
        public int Id { get; set; }

        [Required(ErrorMessage = "Naam is verplicht.")]
        public string Naam { get; set; }

        [Required(ErrorMessage = "Voornaam is verplicht.")]
        public string Voornaam { get; set; }

        [Required(ErrorMessage = "Geboortedatum is verplicht.")]
        public DateTime Geboortedatum { get; set; }

        [Required(ErrorMessage = "Rijgsregisternummer is verplicht.")]
        public string RijksregisterNummer { get; set; }

        [Required(ErrorMessage = "Rijbewijs is verplicht.")]
        public string TypeRijbewijs { get; set; }

        [Required(ErrorMessage = "InDienst is verplicht.")]
        public bool IsVerwijderd { get; set; }


        //################ ADRES ################

        public int AdresId { get; set; }    

        [Required(ErrorMessage = "Straat is verplicht")]
        public string Straat {  get; set; }

        [Required(ErrorMessage = "Huisnummer is verplicht")]
        public string Nummer { get; set; }

        [Required(ErrorMessage = "Postcode is verplicht")]
        public string Stad { get; set; }

        [Required(ErrorMessage = "Stad is verplicht")]
        public string Postcode { get; set; }


        //################ AUTO ################
        public int? AutoId { get; set; }

        
        //################ TANKKAART ###########
        public int? TankkaartId { get; set; }
    }

}
