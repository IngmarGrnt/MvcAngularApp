﻿
using System.ComponentModel.DataAnnotations;

namespace FleetManagement.BL.Dto
{
   
    public class AdresDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Straat is verplicht")]
        public string Straat { get; set; }

        [Required(ErrorMessage = "Huisnummer is verplicht")]
        public string Nummer { get; set; }

        [Required(ErrorMessage = "Postcode is verplicht")]
        public string Postcode { get; set; }

        [Required(ErrorMessage = "Stad is verplicht")]
        public string Stad { get; set; }
    }
}
