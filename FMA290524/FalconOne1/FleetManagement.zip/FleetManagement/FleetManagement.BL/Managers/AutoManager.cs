﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;

namespace FleetManagement.BL.Managers
{
    public class AutoManager : GenericManager<Auto>, IAutoManager
    {
        private readonly IMapper _mapper;
        private readonly IAutoRepository _autoRepo;
        private readonly IBestuurderRepository _bestuurderRepo;
        private readonly IGenericRepository<Auto> _genericRepo;

        public AutoManager(IAutoRepository autoRepository, IGenericRepository<Auto> genericRepo, IMapper mapper, IBestuurderRepository bestuurderRepo) : base(genericRepo)
        {
            _autoRepo = autoRepository;
            _genericRepo = genericRepo;
            _mapper = mapper;
            _bestuurderRepo = bestuurderRepo;
        }

        public int AddAuto(AutoDto autoDto)
        {
            try
            {
                //voegt auto toe, als voor any reason de autodto null is, wordt er een exception gegooid
                if (autoDto == null)
                {
                    throw new ArgumentNullException(nameof(autoDto), "AutoDto value is null");
                }

                Auto auto = _mapper.Map<Auto>(autoDto);
                int id = AddEntity(auto);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            
        }

        public void UpdateAuto(AutoDto autoDto)
        {
            try
            {
                Auto bestaandeAuto = GetEntityById(autoDto.Id);
                _mapper.Map(autoDto, bestaandeAuto);
                UpdateEntity(bestaandeAuto);

                //Als de Auto ut dienst gaat zet in bestuurders AutoId op NULL
                if (bestaandeAuto.IsVerwijderd)
                {
                    bestaandeAuto.IsBeschikbaar = false;
                    //eerst checken of de auto wel gelinkt is aan een bestuurder
                    if (_bestuurderRepo.AutoIsLinkedToABestuurder(bestaandeAuto.Id))
                    {
                        _bestuurderRepo.SetAutotIdNull(bestaandeAuto.Id);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            
        }

        async Task<List<AutoDto>> IAutoManager.GetAllAutosAsync()
        {
            try
            {
                //getAll() van genericrepo, daarna mappen van auto-entity naar autodto lijst
                var autos = await GetAllAsync();
                List<AutoDto> autoDtos = _mapper.Map<List<AutoDto>>(autos);
                return autoDtos;
            }
            catch (Exception ex) 
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<bool> CheckDuplicateNummerplaat(string nummerplaat, int id)
        {
            try
            {
                //doorgeefluik naar dal waar er gecheckt wordt of er een eenzelfde nummerplaat bestaat met een andere id als de meegegeven id
                var existingAuto = await _autoRepo.CheckDuplicateNummerplaatAsync(nummerplaat, id);
                return existingAuto;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<bool> CheckDuplicateChassisNummer(string chassisnummer, int id)
        {
            try
            {
                //doorgeefluik naar dal waar er gecheckt wordt of er een eenzelfde chassisnummer bestaat met een andere id als de meegegeven id
                var existingAuto = await _autoRepo.CheckDuplicateChassisNummerAsync(chassisnummer, id);
                return existingAuto;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
