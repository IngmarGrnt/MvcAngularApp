﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;

namespace FleetManagement.BL.Managers
{
    public class HistoriekManager : GenericManager<Historiek>, IHistoriekManager
    {
        private readonly IMapper _mapper;


        public HistoriekManager(IMapper mapper, IGenericRepository<Historiek> genericRepo) : base(genericRepo)
        {
            _mapper = mapper;
        }

        public async Task<List<HistoriekDto>> GetAllHistorieksAsync()
        {
            try
            {
                var historiek = GetAllEntities();
                List<HistoriekDto> historiekDto = _mapper.Map<List<HistoriekDto>>(historiek);
                return historiekDto;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            
        }
    }
}
