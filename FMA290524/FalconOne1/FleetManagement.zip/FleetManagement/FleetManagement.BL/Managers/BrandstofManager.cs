﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;

namespace FleetManagement.BL.Managers
{
    public class BrandstofManager : GenericManager<Brandstof>, IBrandstofManager
    {
        private readonly IMapper _mapper;
        private IGenericRepository<Brandstof> _repository;  
        public BrandstofManager(IGenericRepository<Brandstof> repository, IMapper mapper) : base(repository)
        {
            _mapper = mapper;
            _repository = repository;
        }

        public int AddBrandstof(BrandstofDto brandstofDto)
        {
            Brandstof brandstof = _mapper.Map<Brandstof>(brandstofDto);
            int id = AddEntity(brandstof);
            return id;
        }

        public void DeleteBrandstof(int id)
        {
            try
            {
                _repository.Delete(id);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
            
        }

        public async Task<List<BrandstofDto>> GetAllBrandstofAsync()
        {
            var brandstofList = await GetAllAsync();

            //als er geen brandstoffen zijn, return een lege lijst
            if (brandstofList == null)
            {
                return new List<BrandstofDto>();
            }

            //sorting alfabetisch
            List<BrandstofDto> brandstofDtoList = _mapper.Map<List<BrandstofDto>>(brandstofList);
            brandstofDtoList = brandstofDtoList.OrderBy(b => b.Naam).ToList();
            return brandstofDtoList;
        }
    }
}
