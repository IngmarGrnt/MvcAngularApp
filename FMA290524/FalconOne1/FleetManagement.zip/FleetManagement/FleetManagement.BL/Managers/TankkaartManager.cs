﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;

namespace FleetManagement.BL.Managers
{
    public class TankkaartManager : GenericManager<Tankkaart>, ITankkaartManager
    {
        private readonly IMapper _mapper;
        private readonly ITankkaartRepository _tankkaartRepo;
        private readonly IBestuurderRepository _bestuurderRepo;

        private readonly IGenericRepository<Tankkaart> _genericRepo;

        public TankkaartManager(IMapper mapper, ITankkaartRepository tankkaartRepo, IGenericRepository<Tankkaart> genericRepo,IBestuurderRepository bestuurderRepository) : base(genericRepo)
        {
            _mapper = mapper;
            _tankkaartRepo = tankkaartRepo;
            _genericRepo = genericRepo;
            _bestuurderRepo=bestuurderRepository;   
        }

        public Task<List<TankkaartDto>> GetAllTankkaartenAsync()
        {
            try
            {
                var tankkaarten = GetAllEntities();
                List<TankkaartDto> tankkaartDto = _mapper.Map<List<TankkaartDto>>(tankkaarten);
                return Task.FromResult(tankkaartDto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public Task<int> AddTankkaartAsync(TankkaartDto tankkaartDto)
        {
            try
            {
                Tankkaart tankkaart = _mapper.Map<Tankkaart>(tankkaartDto);
                int id = AddEntity(tankkaart);
                return Task.FromResult(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Task UpdateTankkaartAsync(TankkaartDto tankkaartDto)
        {
            try
            {
                Tankkaart bestaandeTankkaart = GetEntityById(tankkaartDto.Id);
                _mapper.Map(tankkaartDto, bestaandeTankkaart);
                UpdateEntity(bestaandeTankkaart);

                //Als de Tankkaart uit dienst  of geblokkeerd word zet in bestuurders TankkaartId op NULL
                if (bestaandeTankkaart.IsGeblokkeerd|| bestaandeTankkaart.IsVerwijderd)
                {
                    SetTankkaartIdNullBestuurder(tankkaartDto.Id);
                }

                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<bool> CheckDuplicateKaartnummer(string kaartnummer, int id)
        {
            try
            {
                var existingKaartNummer = await _tankkaartRepo.CheckDuplicateKaartnummer(kaartnummer, id);
                return existingKaartNummer;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void SetTankkaartIdNullBestuurder(int tankkaartId)
        {
            try
            {
                _bestuurderRepo.SetTankkaartIdNull(tankkaartId);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

        }
    }
}
