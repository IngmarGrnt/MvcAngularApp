﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;

namespace FleetManagement.BL.Managers
{
    
    //Indien we enkel CRUD nodig hebben zou dit voldoende zijn, indien afwijken van standaard crud interface aanmaken.
   
    public class AdresManager : GenericManager<Adres>, IAdresManager
    {
        private readonly IMapper _mapper;

        public AdresManager(IGenericRepository<Adres> repository, IMapper mapper) : base(repository)
        {
           _mapper = mapper;
        }
        public async Task<List<AdresDto>> GetAllAdressenAsync()
        {
            try
            {
                var adressen = GetAllEntities();
                List<AdresDto> adresDto = _mapper.Map<List<AdresDto>>(adressen);
                return adresDto;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

        }
    }
}
