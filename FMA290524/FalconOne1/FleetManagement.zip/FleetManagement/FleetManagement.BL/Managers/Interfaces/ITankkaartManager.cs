﻿using FleetManagement.BL.Dto;
using FleetManagement.Dal.Entities;

namespace FleetManagement.BL.Managers.Interfaces
{
    public interface ITankkaartManager : IGenericManager<Tankkaart>
    {
        Task<List<TankkaartDto>> GetAllTankkaartenAsync();
        Task<int> AddTankkaartAsync(TankkaartDto tankkaartDto);
        Task UpdateTankkaartAsync(TankkaartDto tankkaartDto);
        Task<bool> CheckDuplicateKaartnummer(string kaartnummer, int id);
        void SetTankkaartIdNullBestuurder(int bestuurderId);
    }
}
