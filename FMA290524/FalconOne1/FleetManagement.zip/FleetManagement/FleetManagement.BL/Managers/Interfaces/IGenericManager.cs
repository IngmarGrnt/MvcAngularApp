﻿using FleetManagement.Dal.Entities;

namespace FleetManagement.BL.Managers.Interfaces
{
    public interface IGenericManager<Entity>
        where Entity: BaseEntity
    {
        int AddEntity(Entity entiteit);
        Entity GetEntityById(int id);
        void UpdateEntity(Entity entiteit);
        void DeleteEntity(int id);
        List<Entity> GetAllEntities();
        void SoftDeleteEntity(int id);
    }
}
