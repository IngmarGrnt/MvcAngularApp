﻿using FleetManagement.BL.Dto;
using FleetManagement.Dal.Entities;

namespace FleetManagement.BL.Managers.Interfaces
{
    public interface IBrandstofManager : IGenericManager<Brandstof>
    {
        int AddBrandstof(BrandstofDto brandstofDto);
        void DeleteBrandstof(int id);
        Task<List<BrandstofDto>> GetAllBrandstofAsync();
    }
}
