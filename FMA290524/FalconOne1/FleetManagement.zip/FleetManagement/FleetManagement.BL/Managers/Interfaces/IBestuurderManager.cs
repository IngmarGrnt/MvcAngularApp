﻿using FleetManagement.BL.Dto;
using FleetManagement.Dal.Entities;

namespace FleetManagement.BL.Managers.Interfaces
{
    public interface IBestuurderManager : IGenericManager<Bestuurder>
    {
        Task<int> AddBestuurderAsync(BestuurderDto bestuurderDto);
        BestuurderDto GetBestuurderById(int id);
        Task UpdateBestuurderAsync(BestuurderDto bestuurderDto);
        Task<List<BestuurderDto>> GetAllBestuurdersAsync();
        void ValideerInputRijksregisterNummer(BestuurderDto bestuurderDto);
        Task<bool> CheckDuplicateRijksregisterNr(string rijksregisterNr, int id);

    }
}
