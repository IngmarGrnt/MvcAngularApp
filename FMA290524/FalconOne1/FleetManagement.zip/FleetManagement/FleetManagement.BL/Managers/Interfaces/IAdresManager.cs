﻿using FleetManagement.BL.Dto;
using FleetManagement.Dal.Entities;

namespace FleetManagement.BL.Managers.Interfaces
{
    public interface IAdresManager : IGenericManager<Adres>
    {
        Task<List<AdresDto>> GetAllAdressenAsync();
    }
}
