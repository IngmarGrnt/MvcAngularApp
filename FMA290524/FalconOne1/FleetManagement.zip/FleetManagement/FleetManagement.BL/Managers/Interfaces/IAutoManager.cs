﻿using FleetManagement.BL.Dto;
using FleetManagement.Dal.Entities;

namespace FleetManagement.BL.Managers.Interfaces
{
    public interface IAutoManager : IGenericManager<Auto>
    {
        Task<List<AutoDto>> GetAllAutosAsync();
        int AddAuto(AutoDto autoDto);
        void UpdateAuto(AutoDto autoDto);
        Task<bool> CheckDuplicateNummerplaat(string nummerplaat, int id);
        Task<bool> CheckDuplicateChassisNummer(string chassisnummer, int id);
    }
}
