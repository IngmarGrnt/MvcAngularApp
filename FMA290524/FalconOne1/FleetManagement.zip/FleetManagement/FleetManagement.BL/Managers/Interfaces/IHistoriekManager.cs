﻿using FleetManagement.BL.Dto;
using FleetManagement.Dal.Entities;

namespace FleetManagement.BL.Managers.Interfaces
{
    public interface IHistoriekManager : IGenericManager<Historiek>
    {
        Task<List<HistoriekDto>> GetAllHistorieksAsync();
    }
}
