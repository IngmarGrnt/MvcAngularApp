﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;

namespace FleetManagement.BL.Managers
{
    //Toevoegen van een extra IbestuurderRepo, zo kunnen we extra functionaliteiten toevoegen ten opzichte van de basis crud
    public class BestuurderManager : GenericManager<Bestuurder>, IBestuurderManager
    {
        private readonly IBestuurderRepository _bestuurderRepository;
        private readonly IGenericRepository<Historiek> _historiekRepository;
        private readonly IGenericRepository<Adres> _adresRepository;
        private readonly IMapper _mapper;

        public BestuurderManager(IBestuurderRepository repository, IGenericRepository<Adres> adresRepository, IGenericRepository<Historiek> historiekRepository, IMapper mapper) : base(repository)
        {
            _bestuurderRepository = repository;
            _mapper = mapper;
            _adresRepository = adresRepository;
            _historiekRepository = historiekRepository;
        }

        public async Task <int> AddBestuurderAsync(BestuurderDto bestuurderDto)
        {
            try
            {
                ValideerInputRijksregisterNummer(bestuurderDto);
                Bestuurder bestuurder = new Bestuurder();

                int adresId = ZoekAdresId(bestuurderDto);
                bestuurderDto.AdresId = adresId;    

                bestuurder = _mapper.Map<Bestuurder>(bestuurderDto);
                int id = AddEntity(bestuurder);

                return id;

            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task UpdateBestuurderAsync(BestuurderDto bestuurderDto)
        {
            try
            {
                ValideerInputRijksregisterNummer(bestuurderDto);
                int adresId = ZoekAdresId(bestuurderDto);

                bestuurderDto.AdresId = adresId;
                Bestuurder bestaandeBestuurder = GetEntityById(bestuurderDto.Id);

                if (bestuurderDto.IsVerwijderd)
                {
                    bestuurderDto.AutoId=null;
                    bestuurderDto.TankkaartId=null; 
                }

                _mapper.Map(bestuurderDto, bestaandeBestuurder);
                //bestaandeBestuurder.Geboortedatum = FormatDateTime(bestuurderDto);
                UpdateEntity(bestaandeBestuurder);
            }
            catch (ArgumentException ex)
            {
                throw new ArgumentException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            SlaHistoriekOp(bestuurderDto);
        }

        public BestuurderDto GetBestuurderById(int id)
        {
            BestuurderDto bestuurderDto = _mapper.Map<BestuurderDto>(GetEntityById(id));

            return bestuurderDto;
        }


        public async Task <List<BestuurderDto>> GetAllBestuurdersAsync()
        {
            try
            {
                var bestuurders = GetAllEntities();
                List<BestuurderDto> bestuurderDtos = _mapper.Map<List<BestuurderDto>>(bestuurders);
                return bestuurderDtos;
            }
            catch (Exception ex)
            {
                throw new Exception (ex.Message);
            }
           
        }

        public void ValideerInputRijksregisterNummer(BestuurderDto bestuurderDto)
        {

            //https://nl.wikipedia.org/wiki/Rijksregisternummer

            var rijksregisterInput = bestuurderDto.RijksregisterNummer;

            //Controle op enkel cijfers
            if (rijksregisterInput.Any(char.IsLetter))
            {
                throw new ArgumentException("Ongeldig rijksregisternummer. Alleen CIJFERS zijn toegestaan!\nVerwacht formaat: XXXXXX-XXX.XX");
            }

            //Controle op een totale cijferlengte + tekens op 13
            if (rijksregisterInput.Length != 13) 
            {
                throw new ArgumentException($"Ongeldig rijksregisternummer formaat. Rijksregisternummer heeft 13 karakters!\nVerwacht formaat: XXXXXX-XXX.XX");
            }

            //Verwijder de tekens vanuit de UI
            string rijksregisternummerZonderTekens = rijksregisterInput.Replace("-", "").Replace(".", "");

            //Ontleden van rijksregisternummer
            string RijksregisterGeboortedatumOmgekeerdString = rijksregisternummerZonderTekens.Substring(0, 6);
            string reeksnummer = rijksregisternummerZonderTekens.Substring(6, 3);
            string controleGetal = rijksregisternummerZonderTekens.Substring(9, 2);

            //Controleren van rijksregisternummer met geboortedatum
            DateTime geboorteDatumDto = bestuurderDto.Geboortedatum;
            string omgekeerdeGeboorteDatumDto = geboorteDatumDto.ToString("yyMMdd");

            if (RijksregisterGeboortedatumOmgekeerdString != omgekeerdeGeboorteDatumDto.Substring(0, 6))
            {
                throw new ArgumentException("Geboortedatum komt niet overeen met het rijksregisternummer.");
            }

           //eerste 9 cijfers -> omgekeerdegeboortedatum + reeksnummer. (in string vorm, niet in een optelsom! = 1 groot getal)
            string eerste9Cijfers = RijksregisterGeboortedatumOmgekeerdString + reeksnummer;

            //Controle geboortedatum na 1999 en 2 toevoegen als prefix.
            if (geboorteDatumDto.Year > 1999)
            {
                eerste9Cijfers = "2" + eerste9Cijfers;
            }

            //De eerste 9 cijfers omzetten van string naar long. (Long -> lang getal)
            long eerste9CijfersLong = long.Parse(eerste9Cijfers);

            //restdeling bepalen
            int restdeling = (int)(eerste9CijfersLong % 97);

            //Controle getal berekenen
            int berekendControleGetal = 97 - restdeling;

            //berekend controle getal vergelijken met effectief controle getal. (laatste 2 cijfers van rijkgsr.)
            if (berekendControleGetal != int.Parse(controleGetal))
            {
                throw new ArgumentException("Controlegetal van rijksregisternummer is ongeldig.");
            }

        }

        // CHECK FOR DUPLICATE RIJKSREGISTERNUMMER
        public async Task<bool> CheckDuplicateRijksregisterNr(string rijksregisterNr, int id)
        {
            try
            {
                var existingRijksregisterNr = await _bestuurderRepository.CheckDuplicateRijksregisterNr(rijksregisterNr, id);
                return existingRijksregisterNr;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

        }

        private string FormatDateTime(BestuurderDto bestuurderDto)
        {
            return bestuurderDto.Geboortedatum.ToString("dd/MM/yyyy");
        }

        //CHECK OF HET ADDRES AL BESTAAT
        private int ZoekAdresId(BestuurderDto bestuurderDto)//Geeft ID of null terug
        {
            try
            {
                int adresId;

                //Zoek naar adresId als er een adres bestaat anders is het null
                int? bestaandAdresId = _bestuurderRepository.ZoekAdresId(bestuurderDto.Straat, bestuurderDto.Nummer, bestuurderDto.Postcode, bestuurderDto.Stad);

                if (bestaandAdresId.HasValue)
                {
                    //Gebruik het ID van het bestaande adres
                    adresId = bestaandAdresId.Value;
                }
                else
                {
                    //Maak een nieuw adres aan als het niet bestaat
                    Adres nieuwAdres = new Adres
                    {
                        Straat = bestuurderDto.Straat,
                        Nummer = bestuurderDto.Nummer,
                        Postcode = bestuurderDto.Postcode,
                        Stad = bestuurderDto.Stad
                    };
                    adresId = _adresRepository.Add(nieuwAdres);
                }
                return adresId;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }
            
        }

        private void SlaHistoriekOp(BestuurderDto bestuurderDto)
        {
            Historiek historiek = new Historiek
            {
                AutoId = bestuurderDto.AutoId,
                BestuurderId = bestuurderDto.Id,
                TankkaartId = bestuurderDto.TankkaartId,
                Datum = DateTime.Now
            };

            try
            {
                _historiekRepository.Add(historiek);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }
           
        }
    }
}

