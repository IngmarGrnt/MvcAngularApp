﻿using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Entities;
using FleetManagement.Dal.Repositories.Interfaces;
using System.Data.Common;

namespace FleetManagement.BL.Managers
{

    //basic CRUD transacties via de GenericManager voor alle klasses
    //Dit voor alle klasses die overerven van BaseEntity, is dus een extra veiligheid ipv where: class
    //foutboodschappen worden opgegooid naar de front end (komende van de dal)
    public class GenericManager<Entity> : IGenericManager<Entity>
        where Entity : BaseEntity
    {
    
        protected IGenericRepository<Entity> _genericRepository; 

        public GenericManager(IGenericRepository<Entity> repository)
        {
            _genericRepository = repository;
        }

        public int AddEntity(Entity entiteit)
        {
            try
            {
                int id = _genericRepository.Add(entiteit);
                return id;
            }
            catch (ArgumentNullException)
            {
                throw;
            }
           
            catch (Exception )
            {
                throw;
            }
        }

        public Entity GetEntityById(int id)
        {
            try
            {
                return _genericRepository.GetById(id);
            }
            catch (ArgumentNullException)
            {
                throw;
            }
          
            catch (Exception)
            {
                throw;
            }
         
        }

        public void UpdateEntity(Entity entiteit)
        {
            try
            {
                _genericRepository.Update(entiteit);
            }
            catch (ArgumentNullException)
            {
                throw;
            }

            catch (Exception)
            {
                throw;
            }
        }

        public void DeleteEntity(int id)
        {
            try
            {
                _genericRepository.Delete(id);
            }
            catch (ArgumentNullException)
            {
                throw;
            }
           
            catch (Exception)
            {
                throw;
            }
        }

        public List<Entity> GetAllEntities()
        {
            try
            {
                return _genericRepository.GetAll();
            }
            catch (ArgumentNullException)
            {
                throw;
            }

            catch (Exception)
            {
                throw;
            }
        }
        public Task<List<Entity>> GetAllAsync()
        {
            try
            {
                return _genericRepository.GetAllAsync();
            }
            catch (ArgumentNullException)
            {
                throw;
            }

            catch (Exception)
            {
                throw;
            }
        }

        public void SoftDeleteEntity(int id)
        {
            try
            {
                _genericRepository.SoftDelete(id);
            }
            catch (ArgumentNullException)
            {
                throw;
            }
            
            catch (Exception)
            {
                throw;
            }
        }



    }
}
