﻿using AutoMapper;
using FleetManagement.BL.Dto;
using FleetManagement.Dal.Entities;

namespace FleetManagement.BL.Automapper
{
    public class DtoMappers : Profile
    {

        //AutoMapper werkt door het definiëren van een "mapping" tussen twee objecttypen. Eenmaal een mapping is gedefinieerd,
        //kan AutoMapper deze gebruiken om automatisch een instantie van het ene type naar het andere te kopiëren. 
        public DtoMappers()
        {
            CreateMap<Adres, AdresDto>().ReverseMap();
            CreateMap<Auto, AutoDto>().ReverseMap();
            CreateMap<Bestuurder, BestuurderDto>().ReverseMap();
            CreateMap<Brandstof, BrandstofDto>().ReverseMap();
            CreateMap<Tankkaart, TankkaartDto>().ReverseMap();
            CreateMap<Historiek,HistoriekDto>().ReverseMap();   
        }
    }
}
