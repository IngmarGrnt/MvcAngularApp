﻿namespace FleetManagement.App
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            tankkaart = new Label();
            textBox1 = new TextBox();
            panel2 = new Panel();
            label1 = new Label();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            Overzicht = new Button();
            panel1 = new Panel();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            dataGridView1 = new DataGridView();
            button7 = new Button();
            openFileDialog1 = new OpenFileDialog();
            textBox2 = new TextBox();
            helpProvider1 = new HelpProvider();
            helpProvider2 = new HelpProvider();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(600, 146);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(948, 628);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 1;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.BackColor = Color.Transparent;
            button3.ForeColor = Color.DeepSkyBlue;
            button3.Location = new Point(831, 628);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 2;
            button3.Text = "button3";
            button3.UseVisualStyleBackColor = false;
            // 
            // tankkaart
            // 
            tankkaart.AutoSize = true;
            tankkaart.Font = new Font("Segoe UI", 15F);
            tankkaart.Location = new Point(225, 57);
            tankkaart.Name = "tankkaart";
            tankkaart.Size = new Size(218, 35);
            tankkaart.TabIndex = 3;
            tankkaart.Text = "Beheer Bestuurder";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(225, 146);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(322, 27);
            textBox1.TabIndex = 4;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(button6);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(Overzicht);
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(0);
            panel2.Name = "panel2";
            panel2.Size = new Size(202, 716);
            panel2.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(31, 9);
            label1.Name = "label1";
            label1.Size = new Size(137, 20);
            label1.TabIndex = 9;
            label1.Text = "Fleet Management ";
            label1.Click += label1_Click;
            // 
            // button6
            // 
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Segoe UI", 12F);
            button6.ForeColor = Color.WhiteSmoke;
            button6.Location = new Point(31, 253);
            button6.Name = "button6";
            button6.Size = new Size(125, 46);
            button6.TabIndex = 8;
            button6.Text = "Tankkaarten";
            button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI", 12F);
            button5.ForeColor = Color.WhiteSmoke;
            button5.Location = new Point(31, 320);
            button5.Name = "button5";
            button5.Size = new Size(125, 46);
            button5.TabIndex = 2;
            button5.Text = "Voertuigen";
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 12F);
            button4.ForeColor = Color.WhiteSmoke;
            button4.Location = new Point(31, 183);
            button4.Name = "button4";
            button4.Size = new Size(125, 46);
            button4.TabIndex = 1;
            button4.Text = "Bestuurders";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // Overzicht
            // 
            Overzicht.FlatAppearance.BorderSize = 0;
            Overzicht.FlatStyle = FlatStyle.Flat;
            Overzicht.Font = new Font("Segoe UI", 12F);
            Overzicht.ForeColor = Color.WhiteSmoke;
            Overzicht.Location = new Point(31, 81);
            Overzicht.Name = "Overzicht";
            Overzicht.Size = new Size(116, 46);
            Overzicht.TabIndex = 0;
            Overzicht.Text = "Overzicht";
            Overzicht.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Location = new Point(200, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(972, 33);
            panel1.TabIndex = 7;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(225, 190);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(101, 24);
            checkBox1.TabIndex = 8;
            checkBox1.Text = "checkBox1";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(225, 220);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(101, 24);
            checkBox2.TabIndex = 9;
            checkBox2.Text = "checkBox2";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(225, 249);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(101, 24);
            checkBox3.TabIndex = 10;
            checkBox3.Text = "checkBox3";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(226, 324);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(468, 333);
            dataGridView1.TabIndex = 11;
            // 
            // button7
            // 
            button7.BackColor = Color.Transparent;
            button7.ForeColor = Color.Crimson;
            button7.Location = new Point(1059, 628);
            button7.Name = "button7";
            button7.Size = new Size(94, 29);
            button7.TabIndex = 12;
            button7.Text = "button7";
            button7.UseVisualStyleBackColor = false;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(831, 218);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(322, 27);
            textBox2.TabIndex = 13;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(831, 287);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(322, 27);
            textBox3.TabIndex = 14;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(1010, 356);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(143, 27);
            textBox4.TabIndex = 15;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(831, 356);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(143, 27);
            textBox5.TabIndex = 16;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(831, 417);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(143, 27);
            textBox6.TabIndex = 17;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(1010, 417);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(143, 27);
            textBox7.TabIndex = 18;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(831, 481);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(322, 27);
            textBox8.TabIndex = 19;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(831, 546);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(322, 27);
            textBox9.TabIndex = 20;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 8F);
            label2.Location = new Point(831, 193);
            label2.Name = "label2";
            label2.Size = new Size(45, 19);
            label2.TabIndex = 21;
            label2.Text = "Naam";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 8F);
            label3.Location = new Point(831, 265);
            label3.Name = "label3";
            label3.Size = new Size(45, 19);
            label3.TabIndex = 22;
            label3.Text = "Naam";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 8F);
            label4.Location = new Point(831, 334);
            label4.Name = "label4";
            label4.Size = new Size(45, 19);
            label4.TabIndex = 23;
            label4.Text = "Naam";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 8F);
            label5.Location = new Point(1010, 334);
            label5.Name = "label5";
            label5.Size = new Size(45, 19);
            label5.TabIndex = 24;
            label5.Text = "Naam";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1174, 716);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox9);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(button7);
            Controls.Add(dataGridView1);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Controls.Add(textBox1);
            Controls.Add(tankkaart);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Label tankkaart;
        private TextBox textBox1;
        private Panel panel2;
        private Panel panel1;
        private Button Overzicht;
        private Button button4;
        private Button button5;
        private Label label1;
        private Button button6;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private DataGridView dataGridView1;
        private Button button7;
        private OpenFileDialog openFileDialog1;
        private TextBox textBox2;
        private HelpProvider helpProvider1;
        private HelpProvider helpProvider2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}
