﻿<script>
    function showDeleteConfirmation(message) {
    return confirm(message); // Dit toont een dialoog met OK en Cancel knoppen.
}
</script>