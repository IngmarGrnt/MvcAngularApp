using FleetManagement.App.UI.Components;
using FleetManagement.BL.Automapper;
using FleetManagement.BL.Managers;
using FleetManagement.BL.Managers.Interfaces;
using FleetManagement.Dal.Context;
using FleetManagement.Dal.Repositories;
using FleetManagement.Dal.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Globalization;


var builder = WebApplication.CreateBuilder(args);

var cultureInfo = new CultureInfo("nl-NL");
CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

//DB setup -> via appsettings.json
builder.Services.AddDbContext<FleetManagementDbContext>(options =>
    options.UseMySql(builder.Configuration.GetConnectionString("FleetManagementDb"), new MySqlServerVersion(new Version(8, 0, 21))));
//automapper 
//Automapper Zoekt in de assembly (gecompileerd codebestand vb: dll, die kan uitgevoerd worden op runtime) 
//collectie alle automapper profielen en registreert deze
builder.Services.AddAutoMapper(typeof(DtoMappers).Assembly);

//services toevoegen aan DI container
builder.Services.AddTransient<IBestuurderManager, BestuurderManager>();
builder.Services.AddTransient<IAutoRepository, AutoRepository>();
builder.Services.AddTransient<IBestuurderRepository, BestuurderRepository>();
builder.Services.AddTransient<ITankkaartRepository, TankkaartRepository>();
builder.Services.AddTransient<IHistoriekRepository, HistoriekRepository>();

builder.Services.AddTransient<IAdresManager,AdresManager>();
builder.Services.AddTransient<IAutoManager, AutoManager>();
builder.Services.AddTransient<ITankkaartManager, TankkaartManager>();
builder.Services.AddTransient<IBrandstofManager, BrandstofManager>();
builder.Services.AddTransient<IHistoriekManager, HistoriekManager>();

builder.Services.AddTransient(typeof(IGenericManager<>), typeof(GenericManager<>)); //type kan verschillen, vandaar typeof
builder.Services.AddTransient(typeof(IGenericRepository<>), typeof(GenericRepository<>));
builder.Services.AddHttpClient();

builder.Services.AddQuickGridEntityFrameworkAdapter();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
 .AddInteractiveServerRenderMode();

app.Run();
