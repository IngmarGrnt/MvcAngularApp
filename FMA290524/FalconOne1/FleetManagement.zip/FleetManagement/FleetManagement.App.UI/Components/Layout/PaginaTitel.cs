﻿namespace FleetManagement.App.UI.Components.Layout
{
    public static class PaginaTitel
    {
        private static string title = "Default Title";

        public static string Title
        {
            get => title;
            set
            {
                if (title != value)
                {
                    title = value;
                    TitleChanged?.Invoke();

                }
            }
        }

        public static event Action? TitleChanged;
    }
}
