﻿namespace FleetManagement.App.UI.Components.Pages.VoertuigPages
{
    public enum EnumVoertuigDeuren
    {
        twee = 2,
        drie = 3,
        vier = 4,
        vijf = 5

    }
}
