﻿namespace FleetManagement.App.UI.Components.Pages.VoertuigPages
{
    public enum EnumVoeruigTypes
    {
        Sedan,Hatchback,SUV,Coupé,Cabriolet,Stationwagen,Minivan,PickupTruck,Sportwagen
    }
}
