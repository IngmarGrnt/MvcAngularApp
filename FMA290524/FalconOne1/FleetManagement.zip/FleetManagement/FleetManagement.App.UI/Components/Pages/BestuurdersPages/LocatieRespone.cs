﻿using System.Text.Json.Serialization;

namespace FleetManagement.App.UI.Components.Pages.BestuurdersPages
{
    public class LocatieResponse
    {
       // public List<string> SuggestionResult { get; set; }
        public List<LocatieResult> LocationResult { get; set; }
       
    }

    public class LocatieResult
    {
        [JsonPropertyName("Municipality")]
        public string Stad { get; set; }

        [JsonPropertyName("Zipcode")]
        public string Postcode { get; set; }

        [JsonPropertyName("Thoroughfarename")]
        public string Straat { get; set; }

        [JsonPropertyName("Housenumber")]
        public string Nummer { get; set; }

        public long ID { get; set; }
        public string FormattedAddress { get; set; }
        public Location Location { get; set; }
        public string LocationType { get; set; }
        public BoundingBox BoundingBox { get; set; }
    }

    public class Location
    {
        public double Lat_WGS84 { get; set; }
        public double Lon_WGS84 { get; set; }
        public double X_Lambert72 { get; set; }
        public double Y_Lambert72 { get; set; }
    }

    public class BoundingBox
    {
        public Corner LowerLeft { get; set; }
        public Corner UpperRight { get; set; }
    }

    public class Corner
    {
        public double Lat_WGS84 { get; set; }
        public double Lon_WGS84 { get; set; }
        public double X_Lambert72 { get; set; }
        public double Y_Lambert72 { get; set; }
    }
   
}
