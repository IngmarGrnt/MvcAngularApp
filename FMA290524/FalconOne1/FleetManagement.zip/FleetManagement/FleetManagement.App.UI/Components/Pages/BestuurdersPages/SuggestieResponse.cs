﻿namespace FleetManagement.App.UI.Components.Pages.BestuurdersPages
{
    public class SuggestieResponse
    {
        public List<string> SuggestionResult { get; set; }
    }
}
