﻿namespace FleetManagement.App.UI.Components.Pages.BestuurdersPages
{
    public enum EnumRijbewijs
    {
      Geen,A,B,BE,C,CE,D,DE,G
    }
}
